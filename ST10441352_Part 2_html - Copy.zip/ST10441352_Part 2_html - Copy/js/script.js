/**
 * Sneaker Mode - Main JavaScript File
 * Handles cart functionality, form validation, toast notifications, and interactive elements
 */

// Toast Notification Manager
class ToastManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupToastEventListeners();
    }

    setupToastEventListeners() {
        // Enquiry form submission
        const enquiryForm = document.getElementById('enquiryForm');
        if (enquiryForm) {
            enquiryForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (this.validateForm(enquiryForm)) {
                    this.showToast('Enquiry submitted successfully! We will contact you within 24 hours.', 'success');
                    enquiryForm.reset();
                }
            });
        }

        // Contact form submission
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                if (this.validateForm(contactForm)) {
                    this.showToast('Message sent successfully! We will respond within 24 hours.', 'success');
                    contactForm.reset();
                }
            });
        }

        // Newsletter form submission
        const newsletterForm = document.querySelector('.newsletter-form');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const email = newsletterForm.querySelector('input[type="email"]');
                if (this.isValidEmail(email.value)) {
                    this.showToast(`Thank you! ${email.value} has been subscribed to our newsletter.`, 'success');
                    newsletterForm.reset();
                } else {
                    this.showToast('Please enter a valid email address.', 'error');
                }
            });
        }
    }

    validateForm(form) {
        let isValid = true;
        const requiredFields = form.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                this.showFieldError(field, 'This field is required');
                isValid = false;
            } else {
                this.clearFieldError(field);
                
                if (field.type === 'email' && !this.isValidEmail(field.value)) {
                    this.showFieldError(field, 'Please enter a valid email address');
                    isValid = false;
                }
                
                if (field.type === 'text' && field.value.length < 2) {
                    this.showFieldError(field, 'Please enter at least 2 characters');
                    isValid = false;
                }
            }
        });

        return isValid;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    showFieldError(field, message) {
        this.clearFieldError(field);
        field.style.borderColor = '#e74c3c';
        
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error-message';
        errorElement.textContent = message;
        errorElement.style.cssText = `
            color: #e74c3c;
            font-size: 0.8rem;
            margin-top: 0.25rem;
            font-weight: 500;
        `;
        
        field.parentNode.appendChild(errorElement);
    }

    clearFieldError(field) {
        field.style.borderColor = '';
        const existingError = field.parentNode.querySelector('.field-error-message');
        if (existingError) {
            existingError.remove();
        }
    }

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast-notification ${type}`;
        
        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
        const backgroundColor = type === 'success' ? '#10b981' : '#ef4444';
        
        toast.innerHTML = `
            <i class="fas ${icon}"></i>
            <span>${message}</span>
            <button class="toast-close"><i class="fas fa-times"></i></button>
        `;
        
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${backgroundColor};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            z-index: 10000;
            max-width: 400px;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        `;
        
        document.body.appendChild(toast);
        
        // Animate in
        setTimeout(() => {
            toast.style.transform = 'translateX(0)';
        }, 100);
        
        // Close button event
        const closeBtn = toast.querySelector('.toast-close');
        closeBtn.addEventListener('click', () => {
            this.removeToast(toast);
        });
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(toast)) {
                this.removeToast(toast);
            }
        }, 5000);
    }

    removeToast(toast) {
        toast.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (document.body.contains(toast)) {
                document.body.removeChild(toast);
            }
        }, 300);
    }
}

// Cart Management
class CartManager {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('sneakerModeCart')) || [];
        this.init();
    }

    init() {
        this.updateCartCount();
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('add-to-cart')) {
                this.addToCart(e.target.closest('.sneaker-card'));
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.closest('.cart-icon')) {
                e.preventDefault();
                this.showCartModal();
            }
        });

        document.addEventListener('change', (e) => {
            if (e.target.name === 'shipping') {
                this.updateCartDisplay();
            }
        });
    }

    addToCart(productCard) {
        const product = {
            id: productCard.dataset.product,
            name: productCard.querySelector('h3').textContent,
            price: parseFloat(productCard.dataset.price),
            image: productCard.querySelector('img').src,
            quantity: 1
        };

        const existingItem = this.cart.find(item => item.id === product.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push(product);
        }

        this.saveCart();
        this.updateCartCount();
        this.showAddToCartMessage(product.name);
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartCount();
        this.updateCartDisplay();
    }

    updateQuantity(productId, change) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            item.quantity += change;
            if (item.quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                this.saveCart();
                this.updateCartCount();
                this.updateCartDisplay();
            }
        }
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getShippingCost() {
        const selectedShipping = document.querySelector('input[name="shipping"]:checked');
        return selectedShipping ? parseFloat(selectedShipping.value) : 0;
    }

    getGrandTotal() {
        return this.getCartTotal() + this.getShippingCost();
    }

    updateCartCount() {
        const cartCountElements = document.querySelectorAll('#cartCount');
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        
        cartCountElements.forEach(element => {
            element.textContent = totalItems;
        });
    }

    updateCartDisplay() {
        const cartSummary = document.getElementById('cartSummary');
        const cartItems = document.getElementById('cartItems');
        const subtotalElement = document.getElementById('subtotal');
        const shippingCostElement = document.getElementById('shippingCost');
        const cartTotalElement = document.getElementById('cartTotal');

        if (cartSummary && cartItems) {
            if (this.cart.length === 0) {
                cartSummary.style.display = 'none';
                return;
            }

            cartSummary.style.display = 'block';
            cartItems.innerHTML = this.cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <img src="${item.image}" alt="${item.name}" width="50" height="50">
                        <span>${item.name}</span>
                    </div>
                    <div class="cart-item-controls">
                        <button class="quantity-btn" onclick="cartManager.updateQuantity('${item.id}', -1)">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="cartManager.updateQuantity('${item.id}', 1)">+</button>
                        <span>R${(item.price * item.quantity).toFixed(2)}</span>
                        <button class="remove-btn" onclick="cartManager.removeFromCart('${item.id}')">Remove</button>
                    </div>
                </div>
            `).join('');

            if (subtotalElement) subtotalElement.textContent = this.getCartTotal().toFixed(2);
            if (shippingCostElement) shippingCostElement.textContent = this.getShippingCost().toFixed(2);
            if (cartTotalElement) cartTotalElement.textContent = this.getGrandTotal().toFixed(2);
        }
    }

    showAddToCartMessage(productName) {
        if (window.toastManager) {
            window.toastManager.showToast(`Added ${productName} to cart!`, 'success');
        }
    }

    showCartModal() {
        const modal = document.createElement('div');
        modal.className = 'cart-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        `;

        modal.innerHTML = `
            <div class="modal-content" style="
                background: white;
                padding: 2rem;
                border-radius: 12px;
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
            ">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3 style="margin: 0; color: #2c3e50;">Shopping Cart</h3>
                    <button class="close-modal" style="
                        background: none;
                        border: none;
                        font-size: 1.5rem;
                        cursor: pointer;
                        color: #7f8c8d;
                    ">×</button>
                </div>
                <div class="modal-cart-items">
                    ${this.cart.length === 0 ? 
                        '<p style="text-align: center; color: #7f8c8d;">Your cart is empty</p>' : 
                        this.cart.map(item => `
                            <div class="modal-cart-item" style="
                                display: flex;
                                align-items: center;
                                padding: 1rem;
                                border-bottom: 1px solid #ecf0f1;
                                gap: 1rem;
                            ">
                                <img src="${item.image}" alt="${item.name}" width="60" height="60" style="border-radius: 8px;">
                                <div style="flex: 1;">
                                    <div style="font-weight: 600; margin-bottom: 0.5rem;">${item.name}</div>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <button onclick="cartManager.updateQuantity('${item.id}', -1)" style="
                                            width: 30px;
                                            height: 30px;
                                            border: 1px solid #bdc3c7;
                                            background: white;
                                            border-radius: 4px;
                                            cursor: pointer;
                                        ">-</button>
                                        <span style="min-width: 20px; text-align: center;">${item.quantity}</span>
                                        <button onclick="cartManager.updateQuantity('${item.id}', 1)" style="
                                            width: 30px;
                                            height: 30px;
                                            border: 1px solid #bdc3c7;
                                            background: white;
                                            border-radius: 4px;
                                            cursor: pointer;
                                        ">+</button>
                                        <span style="margin-left: 1rem; font-weight: 600;">R${(item.price * item.quantity).toFixed(2)}</span>
                                    </div>
                                </div>
                                <button onclick="cartManager.removeFromCart('${item.id}')" style="
                                    background: none;
                                    border: none;
                                    color: #e74c3c;
                                    cursor: pointer;
                                    padding: 0.5rem;
                                    border-radius: 4px;
                                ">×</button>
                            </div>
                        `).join('')
                    }
                </div>
                ${this.cart.length > 0 ? `
                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #ecf0f1;">
                        <div style="display: flex; justify-content: space-between; font-size: 1.2rem; font-weight: 600;">
                            <span>Total:</span>
                            <span>R${this.getGrandTotal().toFixed(2)}</span>
                        </div>
                        <button onclick="cartManager.proceedToCheckout()" style="
                            width: 100%;
                            padding: 1rem;
                            background: #4f46e5;
                            color: white;
                            border: none;
                            border-radius: 8px;
                            font-size: 1.1rem;
                            font-weight: 600;
                            cursor: pointer;
                            margin-top: 1rem;
                        ">Proceed to Checkout</button>
                    </div>
                ` : ''}
            </div>
        `;

        modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.classList.contains('close-modal')) {
                document.body.removeChild(modal);
            }
        });

        document.body.appendChild(modal);
    }

    proceedToCheckout() {
        if (this.cart.length === 0) {
            if (window.toastManager) {
                window.toastManager.showToast('Your cart is empty!', 'error');
            }
            return;
        }
        
        window.location.href = 'Enquiry.html';
    }

    saveCart() {
        localStorage.setItem('sneakerModeCart', JSON.stringify(this.cart));
    }

    clearCart() {
        this.cart = [];
        this.saveCart();
        this.updateCartCount();
        this.updateCartDisplay();
    }
}

// Interactive Elements
class InteractiveElements {
    constructor() {
        this.init();
    }

    init() {
        this.setupImageHoverEffects();
        this.setupSmoothScrolling();
        this.setupCounterAnimations();
    }

    setupImageHoverEffects() {
        document.addEventListener('mouseover', (e) => {
            if (e.target.closest('.sneaker-card')) {
                const card = e.target.closest('.sneaker-card');
                card.style.transform = 'translateY(-5px)';
                card.style.transition = 'transform 0.3s ease';
            }
        });

        document.addEventListener('mouseout', (e) => {
            if (e.target.closest('.sneaker-card')) {
                const card = e.target.closest('.sneaker-card');
                card.style.transform = 'translateY(0)';
            }
        });
    }

    setupSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    setupCounterAnimations() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateValue(entry.target, 0, parseInt(entry.target.textContent), 2000);
                    observer.unobserve(entry.target);
                }
            });
        });

        document.querySelectorAll('.stat-item span').forEach(stat => {
            observer.observe(stat);
        });
    }

    animateValue(element, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            element.textContent = Math.floor(progress * (end - start) + start);
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
}

// SEO Optimization
class SEOOptimizer {
    constructor() {
        this.init();
    }

    init() {
        this.setupStructuredData();
        this.optimizeMetaTags();
    }

    setupStructuredData() {
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "Store",
            "name": "Sneaker Mode",
            "description": "Premier hub for sneaker enthusiasts, collectors, and culture seekers",
            "url": window.location.origin,
            "telephone": "+27-61-444-6734",
            "email": "sneakermode@gmail.com",
            "address": {
                "@type": "PostalAddress",
                "addressLocality": "Port Elizabeth",
                "addressRegion": "Eastern Cape",
                "addressCountry": "ZA"
            },
            "openingHours": "Mo-Fr 09:00-18:00, Sa 09:00-16:00",
            "priceRange": "R1000 - R5000"
        };

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(structuredData);
        document.head.appendChild(script);
    }

    optimizeMetaTags() {
        const pageDescriptions = {
            'index.html': 'Sneaker Mode - Premier hub for sneaker enthusiasts, collectors, and culture seekers',
            'about us.html': 'Learn about Sneaker Mode history, mission, vision and our journey in sneaker culture',
            'services.html': 'Browse our premium sneaker collection including Nike Air Jordans, Adidas Yeezy and more',
            'enquiry.html': 'Submit enquiries about our products, sizing, and return policies',
            'contact.html': 'Contact Sneaker Mode for customer support and general inquiries',
            'map.html': 'Find Sneaker Mode location at Walmer Park Shopping Centre in Port Elizabeth'
        };

        const currentPage = window.location.pathname.split('/').pop() || 'index.html';
        if (pageDescriptions[currentPage.toLowerCase()]) {
            const metaDescription = document.querySelector('meta[name="description"]');
            if (metaDescription) {
                metaDescription.content = pageDescriptions[currentPage.toLowerCase()];
            }
        }
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all managers
    window.toastManager = new ToastManager();
    window.cartManager = new CartManager();
    window.interactiveElements = new InteractiveElements();
    window.seoOptimizer = new SEOOptimizer();

    // Update cart display on services page
    if (document.getElementById('cartSummary')) {
        cartManager.updateCartDisplay();
    }

    // Add loading animation removal
    document.body.classList.add('loaded');

    console.log('Sneaker Mode JavaScript initialized successfully');
});

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
});

// Export for use in other files (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ToastManager, CartManager, InteractiveElements, SEOOptimizer };
}